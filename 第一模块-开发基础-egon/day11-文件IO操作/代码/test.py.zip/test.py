import random
# 补充代码
#生成一副扑克牌（自己设计扑克牌的结构，小王和大王可以分别用14、15表示 ）
total_poke_list = []
color_poke = ['红心','黑桃','方角','梅花']
for i in range(1,14):
    for j in color_poke:
        total_poke_list.append((j,i))
total_poke_list.append(('小王',14))
total_poke_list.append(('大王', 15))
print(total_poke_list)
# 发牌
result = {}
user_list = ["alex","武沛齐","李路飞"]
for i in user_list:
    print(f'当前用户{i}')
    count = 0   #分数计算
    while True:
        # 随机抽取一张牌， 然后删除掉已发牌
        index = random.randint(0,len(total_poke_list)-1)
        poke = total_poke_list.pop(index)
        # jqk 大小王 0.5分
        value = poke[1]
        if poke[1] > 10:
            value = 0.5
        count += value
        print(f'当前发牌{poke},牌面总和{count}')
        if count > 11:
            print('所有牌数大于11 清0')
            result[i] = 0
            break
        dd = input('是否继续要牌 N/n 不要牌，其他任意键要牌 >')
        if dd.upper() == 'N':
            result[i] = count
            break

print(result)
