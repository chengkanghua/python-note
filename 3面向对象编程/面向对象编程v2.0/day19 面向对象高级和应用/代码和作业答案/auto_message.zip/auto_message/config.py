MESSAGE_HANDLER_LIST = [
    "handler.email.Email",
    # "handler.msg.Msg",
    # "handler.wechat.Wechat",
]
