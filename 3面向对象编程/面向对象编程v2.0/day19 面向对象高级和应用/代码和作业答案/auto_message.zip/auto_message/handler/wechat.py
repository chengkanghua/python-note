class Wechat(object):

    def send(self):
        print("发微信")
