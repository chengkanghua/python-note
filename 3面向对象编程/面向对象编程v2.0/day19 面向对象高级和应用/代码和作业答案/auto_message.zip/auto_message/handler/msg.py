class Msg(object):
    def send(self):
        print("发送短信")
