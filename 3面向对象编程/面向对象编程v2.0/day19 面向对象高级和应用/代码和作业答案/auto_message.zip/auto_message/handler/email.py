class Email(object):
    def send(self):
        print("发送邮件")
