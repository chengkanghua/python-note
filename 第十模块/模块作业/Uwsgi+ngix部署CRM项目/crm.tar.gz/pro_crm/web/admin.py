from django.contrib import admin
from web import models
# Register your models here.

# admin.site.register(models.ConsultRecord)