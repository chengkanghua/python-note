# -*- coding:utf-8 -*-
# created by Alex Li - 路飞学城
import os
import shutil



import os
import re
from docx import Document

base_dir = os.path.dirname(os.path.abspath(__file__))



def filter_doc(key_words,doc_filename,file_dir):
    doc_obj = Document(f"{base_dir}/{file_dir}/{doc_filename}")
    print(f"search file {doc_filename}".center(80,"-"))

    matched = False
    for para in doc_obj.paragraphs:
        if re.search(key_words, para.text):
            matched = True
            print(para.text)


    for table_obj in doc_obj.tables:
        #print(table_obj.rows)
        for r in range(len(table_obj.rows)):
            for c in range(len(table_obj.columns)):
                cell_text = table_obj.cell(r,c).text
                if re.search(key_words, cell_text):
                    matched = True
                    print(cell_text)

    if matched:

        file_with_dir = f"{base_dir}/{file_dir}/{filename}"
        shutil.copyfile(file_with_dir, f"{base_dir}/filter_output/{filename}")


resume_files = os.listdir(f"{base_dir}/file_docx_1")
print("简历库数量:",len(resume_files))
while True:
    key_word = input("简历关键字>>:").strip()
    if not key_word:continue
    if key_word == "q":break

    # 先清空之前的搜索纪录
    old_files = os.listdir(f"{base_dir}/filter_output/")
    for f in old_files:
        os.remove(f"{base_dir}/filter_output/{f}")

    for filename in resume_files:
        filter_doc(key_word, filename, "file_docx_1")


