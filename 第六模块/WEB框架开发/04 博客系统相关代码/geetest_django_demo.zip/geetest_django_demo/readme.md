# 使用说明
首先要从极验验证的后台获取一个id和key，请自行申请: https://auth.geetest.com/login

得到的key和id长这样：
```python
pc_geetest_id = "b46d1900d0a894591916ea94ea91bd2c"
pc_geetest_key = "36fc3fe98530eea08dfc6ce76e3d24c4"
```
极验验证的流程：https://docs.geetest.com/sensebot/overview/flowchart/#%E9%80%9A%E8%AE%AF%E6%B5%81%E7%A8%8B

部署文档：https://docs.geetest.com/sensebot/deploy/server/python


# 如何使用本demo
1.首先去部署文档中，去下载sdk压缩包，我这里已经下载好了，就是`gt3-python-sdk-master.zip`这个压缩包。
其中geetest.py和gt.js这两个文件是我们示例种用到的，我已经放到了相应的目录下面了。

另外，那个zip包中还有极验官方提供的相应的示例，你可以自行参考

2.这个demo使用的是Django3.2。
所以，你可以直接使用下面命令下载该demo所需要的依赖。
```text
pip install -i https://pypi.doubanio.com/simple -r requirements.txt
```
3.执行数据库迁移命令

```text
python manage.py makemigrations
python manage.py migrate
```
完事之后，自行在userifo表中添加几个用户信息，用于登录的身份认证

4.接下来就是把Django项目跑起来

5.访问index路由进入主页按照提示运行测试

注意，为了更好的理解，请仔细阅读Ajax提交的示例，相对完善
 