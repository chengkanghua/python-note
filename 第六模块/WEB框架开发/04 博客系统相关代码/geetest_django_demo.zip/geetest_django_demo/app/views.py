import json
from django.shortcuts import render, redirect, HttpResponse
from app.geetest import GeetestLib
from app import models




def index(request):
    """  主页 """
    return render(request, 'index.html')

def login1(request):
    """  form表单中使用嵌入式的极验验证 """
    if request.method == "POST":
        # 获取用户名和密码
        user = request.POST.get("username")
        pwd = request.POST.get("password")
        # print('ajax提交的结果: ', user, pwd)
        current_user_obj = models.UserInfo.objects.filter(username=user, password=pwd).first()
        print('current user', current_user_obj)
        if current_user_obj:
            return redirect('/index/')
        else:
            return render(request, 'login1.html', {"error_msg": "用户名或者密码错误"})
    else:
        return render(request, 'login1.html')

def login2(request):
    """  form表单中使用弹出式极验验证码, 二次验证 """
    if request.method == "POST":
        # 获取用户名和密码
        user = request.POST.get("username")
        pwd = request.POST.get("password")
        # print('ajax提交的结果: ', user, pwd)
        current_user_obj = models.UserInfo.objects.filter(username=user, password=pwd).first()
        print('current user', current_user_obj)
        result = {}
        if current_user_obj:
            result['login_status'] = 'success'
        else:
            result['login_status'] = 'error'
        print('用户登录认证的结果', result)
        return HttpResponse(json.dumps(result))
    else:
        return render(request, 'login2.html')

# 极验验证官方申请的id和key，你们替换为自己的，因为不知道啥时候下面的key和id就失效了
pc_geetest_id = "8845ffc862dc0597b30f78831369a27b"
pc_geetest_key = "2dc2dde1477594e1aebc5534ba3c080f"

def second_validate(request):
    """
    二次验证，即初始化验证码成功，然后用户进行滑动验证，来此校验滑动结果
    同时进行用户信息校验
     """
    if request.method == "POST":
        gt = GeetestLib(pc_geetest_id, pc_geetest_key)
        challenge = request.POST.get(gt.FN_CHALLENGE, '')
        validate = request.POST.get(gt.FN_VALIDATE, '')
        seccode = request.POST.get(gt.FN_SECCODE, '')
        # 获取用户名和密码
        user = request.POST.get("username")
        pwd = request.POST.get("password")
        print('ajax提交的结果: ', user, pwd)
        status = request.session[gt.GT_STATUS_SESSION_KEY]
        current_user_obj = models.UserInfo.objects.filter(username=user, password=pwd).first()
        print('current user', current_user_obj)
        result = {}
        if current_user_obj:
            result['login_status'] = 'success'
        else:
            result['login_status'] = 'error'
        print('用户登录认证的结果', result)
        if status:
            validate_status = gt.success_validate(challenge, validate, seccode)
        else:
            validate_status = gt.failback_validate(challenge, validate, seccode)
        result['validate_status'] = "success" if validate_status else "error"
        return HttpResponse(json.dumps(result))
    return HttpResponse("error")

def pcgetcaptcha(request):
    print(1111111111, '初始化验证码')
    gt = GeetestLib(pc_geetest_id, pc_geetest_key)
    status = gt.pre_process()
    request.session[gt.GT_STATUS_SESSION_KEY] = status
    response_str = gt.get_response_str()
    # {"success": 1, "gt": "8845ffc862dc0597b30f78831369a27b", "challenge": "0d6f087ccf2ccf4ee3fd11dfad3c45da", "new_captcha": true}
    return HttpResponse(response_str)






