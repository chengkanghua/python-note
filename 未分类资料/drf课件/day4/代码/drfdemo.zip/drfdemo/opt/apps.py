from django.apps import AppConfig


class OptConfig(AppConfig):
    name = 'opt'
