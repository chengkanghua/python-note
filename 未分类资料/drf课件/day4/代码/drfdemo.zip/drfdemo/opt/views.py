from rest_framework.viewsets import ViewSet
from rest_framework.response import  Response
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated,IsAdminUser,IsAuthenticatedOrReadOnly

class ExampleAPIView(ViewSet):
    """权限组件的配置使用"""
    permission_classes = [AllowAny]
    @action(methods=["get"],detail=False)
    def auth(self,request):
        return Response("ok")

    @action(methods=["get"], detail=False)
    def login(self,request):
        return Response("登录页面")

from rest_framework.permissions import BasePermission
class ConstomPermission(BasePermission):
    def has_permission(self, request, view):
        if request.user and request.user.username == "xiaoming":
            return True

class Example2APIView(ViewSet):
    permission_classes = [ConstomPermission]
    @action(methods=["get"],detail=False)
    def auth(self,request):
        return Response("ok")