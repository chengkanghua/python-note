from . import views
urlpatterns = []
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register("test", views.ExampleAPIView,basename="test")
router.register("test2", views.Example2APIView,basename="test2")
urlpatterns += router.urls