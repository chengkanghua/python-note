from django.urls import path,re_path
from . import views
urlpatterns = [
    path("students1/", views.Student1APIView.as_view()),
    re_path("^students2/(?P<pk>\d+)/$", views.Student2APIView.as_view()),
    path("students3/", views.Student3APIView.as_view()),
    re_path("^Student6APIView/(?P<pk>\d+)/$", views.Student4APIView.as_view()),
    path("students5/", views.Student5APIView.as_view()),
    re_path("^students6/(?P<pk>\d+)/$", views.Student6APIView.as_view()),
    path("students7/", views.Student7APIViewSet.as_view({"get":"list","post":"post"})),
    re_path("^students7/(?P<pk>\d+)/$", views.Student7APIViewSet.as_view({"get":"get","put":"put","delete":"delete"})),

    path("students8/", views.Student8APIViewSet.as_view({"get": "get", "post": "post"})),
    re_path("^students8/(?P<pk>\d+)/$",
            views.Student8APIViewSet.as_view({"get": "get_one", "put": "put", "delete": "delete"})),

    # path("students9/", views.Student9APIViewSet.as_view({"get": "list", "post": "create"})),
    # re_path("^students9/(?P<pk>\d+)/$",
    #         views.Student9APIViewSet.as_view({"get": "retrieve", "put": "update", "delete": "destroy"})),
]

# 使用路由类给视图集生成路由
from rest_framework.routers import SimpleRouter,DefaultRouter

router = SimpleRouter()
# router.register("路由访问前缀","视图集类","路由别名")
router.register("student9",views.Student9APIViewSet)
print(router.urls)
# 把路由类生成的路由信息合并到项目中
urlpatterns += router.urls
