from rest_framework.response import Response
from rest_framework import status
from rest_framework.generics import GenericAPIView

from students.models import Student
from students.serializers import StudentModelSerializer,Student2ModelSerializer
class Student1APIView(GenericAPIView):
    # 用于指定当前视图类中使用的默认序列化器
    # serializer_class = StudentModelSerializer
    # 用于指定当前视图类中使用的数据集
    queryset = Student.objects.all()

    # get_serializer_class 这个方法主要的作用就是提供给开发者需要在同一个视图类中调用多个序列化器时进行重写时使用的.
    def get_serializer_class(self):
        if self.request.method.lower() == "get":
            return Student2ModelSerializer
        else:
            return StudentModelSerializer

    def get(self,request):
        """获取多条"""
        # serializer = self.serializer_class(instance=self.queryset.all(),many=True)
        serializer = self.get_serializer(instance=self.get_queryset(),many=True)
        return Response(serializer.data)

    def post(self,request):
        """添加信息"""
        serialzier = self.get_serializer(data=request.data,context={})
        serialzier.is_valid(raise_exception=True)
        serialzier.save()
        return Response(serialzier.data)

class Student2APIView(GenericAPIView):
    serializer_class = StudentModelSerializer
    # 面向对象中, 类属性的值不能出现变量赋值的情况,一定要具体的代码逻辑或者具体值
    queryset = Student.objects.all()
    def get(self,request,pk):
        """获取一条数据"""
        # serializer = self.serializer_class(instance=self.queryset.get(pk=pk))
        serializer = self.get_serializer(instance=self.get_object())
        return Response(serializer.data)

    def put(self,request,pk):
        serializer = self.get_serializer(instance=self.get_object(), data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self,request,pk):
        self.get_object().delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

"""
视图扩展类(Mixins),一般都会配合GenericsAPIView或者视图集使用的.
针对基本的API接口代码进行了封装提供了5个常用的视图扩展类
ListModelMixin      获取多条数据  list()
RetrieveModelMixin  获取一条数据  retrieve()
CreateModelMixin    添加一条数据  create()
UpdateModelMixin    更新一条数据  update()
DestroyModelMixin   删除一套数据  destroy()
"""
from rest_framework.mixins import ListModelMixin,RetrieveModelMixin,CreateModelMixin,UpdateModelMixin,DestroyModelMixin
from rest_framework.generics import GenericAPIView
class Student3APIView(GenericAPIView,ListModelMixin,CreateModelMixin):
    serializer_class = StudentModelSerializer
    queryset = Student.objects.all()
    def get(self,request):
        """获取多条数据"""
        return self.list(request)

    def post(self,request):
        """添加一条数据"""
        return self.create(request)

class Student4APIView(GenericAPIView,RetrieveModelMixin,UpdateModelMixin,DestroyModelMixin):
    serializer_class = StudentModelSerializer
    queryset = Student.objects.all()
    def get(self,request,pk):
        """获取一条数据"""
        return self.retrieve(request,pk)

    def put(self,request,pk):
        return self.update(request,pk)

    def delete(self,request,pk):
        return self.destroy(request,pk)

"""
由视图扩展类和通用视图类还可以进行组合,产生新的视图这些视图子类,可以让我们开发基本的API接口变得更加简单
ListAPIView = GenericAPIView + ListModelMixin
CreateAPIView = GenericAPIView + CreateModelMixin  
RetrieveAPIView = GenericAPIView + RetrieveModelMixin
UpdateAPIView = GenericAPIView + UpdateModelMixin
DestroyAPIView = GenericAPIView + DestroyModelMixin

"""
from rest_framework.generics import ListAPIView,CreateAPIView,RetrieveAPIView,UpdateAPIView,DestroyAPIView,RetrieveUpdateDestroyAPIView,RetrieveUpdateAPIView
class Student5APIView(ListAPIView,CreateAPIView):
    serializer_class = StudentModelSerializer
    queryset = Student.objects.all()

# class Student6APIView(RetrieveAPIView,UpdateAPIView,DestroyAPIView):
# class Student6APIView(RetrieveUpdateAPIView,DestroyAPIView):
class Student6APIView(RetrieveUpdateDestroyAPIView):
    serializer_class = StudentModelSerializer
    queryset = Student.objects.all()


"""
为了让视图代码变得更加简短, drf提供了视图集[viewsets],视图集允许开发者自定义类视图方法名,还允许一个类分配多个不同的路由,从而让操作同一个模型的视图方法写在一个视图类中.
ViewSet
GenericViewSet
ModelViewSet
ReadOnlyModelViewSet
"""
from rest_framework.viewsets import ViewSet
class Student7APIViewSet(ViewSet):
    def list(self,request):
        """获取多条数据"""
        student_list = Student.objects.all()
        serializer = StudentModelSerializer(instance=student_list,many=True)
        return Response(serializer.data)

    def post(self,request):
        """添加学生信息"""
        serialzier = StudentModelSerializer(data=request.data)
        serialzier.is_valid(raise_exception=True)
        serialzier.save()
        return Response(serialzier.data)

    def get(self,request,pk):
        """获取一条数据"""
        student = Student.objects.get(pk=pk)
        serializer = StudentModelSerializer(instance=student)
        return Response(serializer.data)

    def put(self,request,pk):
        student = Student.objects.get(pk=pk)
        serializer = StudentModelSerializer(instance=student, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self,request,pk):
        Student.objects.get(pk=pk).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

from rest_framework.viewsets import GenericViewSet
class Student8APIViewSet(GenericViewSet):
    serializer_class = StudentModelSerializer
    queryset = Student.objects.all()

    def get(self,request):
        """获取多条"""
        # serializer = self.serializer_class(instance=self.queryset.all(),many=True)
        serializer = self.get_serializer(instance=self.get_queryset(),many=True)
        return Response(serializer.data)

    def post(self,request):
        """添加信息"""
        serialzier = self.get_serializer(data=request.data,context={})
        serialzier.is_valid(raise_exception=True)
        serialzier.save()
        return Response(serialzier.data)

    def get_one(self,request,pk):
        """获取一条数据"""
        # serializer = self.serializer_class(instance=self.queryset.get(pk=pk))
        serializer = self.get_serializer(instance=self.get_object())
        return Response(serializer.data)

    def put(self,request,pk):
        serializer = self.get_serializer(instance=self.get_object(), data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self,request,pk):
        self.get_object().delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


from rest_framework.viewsets import GenericViewSet,ModelViewSet,ReadOnlyModelViewSet
from rest_framework.mixins import ListModelMixin,CreateModelMixin,RetrieveModelMixin,UpdateModelMixin,DestroyModelMixin
# class Student9APIViewSet(GenericViewSet,ListModelMixin,CreateModelMixin,RetrieveModelMixin,UpdateModelMixin,DestroyModelMixin):
# class Student9APIViewSet(ReadOnlyModelViewSet,CreateModelMixin,UpdateModelMixin,DestroyModelMixin):

"""
路由类会自动帮我们视图集生成基本的5个API接口是因为这5个接口的的名字在系统内部有识别.
我们在视图集中如果另外声明了其他视图方法,希望被外界所访问,则默认需要我们进行配置
可以通过 rest_framework.decorators import action
"""
from rest_framework.decorators import action
class Student9APIViewSet(ModelViewSet):
    serializer_class = StudentModelSerializer
    queryset = Student.objects.all()

    def get_serializer_class(self):
        print(self.action) # 本次请求的视图方法名称
        if self.action.lower() == "list":
            return Student2ModelSerializer
        else:
            return StudentModelSerializer

    """
    methods: 设置那些http请求方法能访问到当前视图方法
    detail: 设置生成路由时,是否附带id到地址中
        True:  <URLPattern '^student9/(?P<pk>[^/.]+)/test_api/$' [name='student-test-api']>
        False: <URLPattern '^student9/test_api/$' [name='student-test-api']>
    url_path: 设置访问当前方法的子路由,如果不配置,则默认是是当前方法名
    """
    @action(methods=["get","post"],detail=True)
    def test_api(self,request):
        return Response("测试数据")
