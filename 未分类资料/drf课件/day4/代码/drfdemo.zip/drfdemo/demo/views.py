from django.core.handlers.wsgi import WSGIRequest
from django.views import View
from rest_framework.views import APIView
from django.http.response import HttpResponse
from django.http.request import HttpRequest
class Student1APIView(APIView):
    def get(self,request):
        """如果当前视图类继承的django的View,则request对象是django.http.request.HttpRequest的实例对象"""
        print(request)
        """打印效果:
        # class Student1APIView(View):
        <WSGIRequest: GET '/demo/students1/'>
        # class Student1APIView(APIView):
        <rest_framework.request.Request object at 0x7f45d46cf208>
        """
        return HttpResponse("ok")

"""使用APIView实现5个数据的基本操作
/students/   GET    获取多条数据
/students/   POST   添加一条数据
    可以写在一个类
/students/<pk>/   GET       获取一条数据
/students/<pk>/   PUT       更新一条数据
/students/<pk>/   DELELTE   删除一条数据
"""
from students.models import Student
from students.serializers import StudentModelSerializer
from rest_framework.response import Response
class Student2APIView(APIView):
    def get(self,request):
        """获取多条数据"""
        student_list = Student.objects.all()
        serializer = StudentModelSerializer(instance=student_list,many=True)
        return Response(serializer.data)

    def post(self,request):
        """添加学生信息"""
        serialzier = StudentModelSerializer(data=request.data)
        serialzier.is_valid(raise_exception=True)
        serialzier.save()
        return Response(serialzier.data)

from rest_framework import status
class Student3APIView(APIView):
    def get(self,request,pk):
        """获取一条数据"""
        student = Student.objects.get(pk=pk)
        serializer = StudentModelSerializer(instance=student)
        return Response(serializer.data)

    def put(self,request,pk):
        student = Student.objects.get(pk=pk)
        serializer = StudentModelSerializer(instance=student, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self,request,pk):
        Student.objects.get(pk=pk).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)