from rest_framework.response import Response
from rest_framework import status
from rest_framework.generics import GenericAPIView

from students.models import Student
from students.serializers import StudentModelSerializer,Student2ModelSerializer
class Student1APIView(GenericAPIView):
    # 用于指定当前视图类中使用的默认序列化器
    # serializer_class = StudentModelSerializer
    # 用于指定当前视图类中使用的数据集
    queryset = Student.objects.all()

    # get_serializer_class 这个方法主要的作用就是提供给开发者需要在同一个视图类中调用多个序列化器时进行重写时使用的.
    def get_serializer_class(self):
        if self.request.method.lower() == "get":
            return Student2ModelSerializer
        else:
            return StudentModelSerializer

    def get(self,request):
        """获取多条"""
        # serializer = self.serializer_class(instance=self.queryset.all(),many=True)
        serializer = self.get_serializer(instance=self.get_queryset(),many=True)
        return Response(serializer.data)

    def post(self,request):
        """添加信息"""
        serialzier = self.get_serializer(data=request.data,context={})
        serialzier.is_valid(raise_exception=True)
        serialzier.save()
        return Response(serialzier.data)

class Student2APIView(GenericAPIView):
    serializer_class = StudentModelSerializer
    # 面向对象中, 类属性的值不能出现变量赋值的情况,一定要具体的代码逻辑或者具体值
    queryset = Student.objects.all()
    def get(self,request,pk):
        """获取一条数据"""
        # serializer = self.serializer_class(instance=self.queryset.get(pk=pk))
        serializer = self.get_serializer(instance=self.get_object())
        return Response(serializer.data)

    def put(self,request,pk):
        serializer = self.get_serializer(instance=self.get_object(), data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self,request,pk):
        self.get_object().delete()
        return Response(status=status.HTTP_204_NO_CONTENT)