from django.urls import path,re_path
from . import views
urlpatterns = [
    path("students1/", views.Student1APIView.as_view()),
    re_path("^students2/(?P<pk>\d+)/$", views.Student2APIView.as_view()),
]

