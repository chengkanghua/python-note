from rest_framework .views import APIView
from rest_framework.request import Request
from rest_framework.response import Response
class StudentAPIView(APIView):
    def get(self,request):
        # print(request)
        # print(request._request) # 原来django里面的
        """打印 结果
        <rest_framework.request.Request object at 0x7f85ec3547b8>
        <WSGIRequest: GET '/req/students/'>
        """
        # 接受客户端上传的数据
        print(request.query_params)
        print( request.query_params.get("user") )
        # 如果查询字符串中出现一个变量有多个值的情况,则使用getlist来提取不要使用get,否则只会提取到最后一个值
        print( request.query_params.get("love") )
        print( request.query_params.getlist("love") )
        """
        请求: http://127.0.0.1:8000//req/students/?user=xiaohong&sex=1&love=backetboll&love=swimming&love=shopping
        打印效果:
        <QueryDict: {'user': ['xiaohong'], 'sex': ['1'], 'love': ['backetboll', 'swimming', 'shopping']}>
        xiaohong
        shopping
        ['backetboll', 'swimming', 'shopping']
        """
        return Response("ok")

    def post(self,request):
        print(request.data)  # {'user': 'admin', 'age': 16}
        # <QueryDict: {'uname': ['xiaoming'], 'age': ['17'], 'avatar': [<InMemoryUploadedFile: 123.jpg (image/jpeg)>]}>
        return Response("ok")

from django.views import View
from rest_framework import status
class StudentView(APIView):
    def get(self,request):
        response = Response("ok",status=status.HTTP_507_INSUFFICIENT_STORAGE)
        response.set_cookie("username","abc")
        response["company"] = "Oldboy"
        return response