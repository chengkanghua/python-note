from django.apps import AppConfig


class ReqConfig(AppConfig):
    name = 'req'
