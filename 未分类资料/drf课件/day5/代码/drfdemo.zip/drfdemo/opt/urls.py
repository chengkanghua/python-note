from . import views
from django.urls import path
urlpatterns = [
    path("t4/list/",views.Example4APIView.as_view({"get":"list"})),
    path("t5/list/",views.Example5APIView.as_view({"get":"list"})),
    path("t6/",views.Example6APIView.as_view({"get":"list"})),
    path("t7/",views.Example7APIView.as_view({"get":"list"})),
]
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register("t1", views.ExampleAPIView,basename="test")
router.register("t2", views.Example2APIView,basename="test2")
router.register("t3", views.Example3APIView,basename="test3")
urlpatterns += router.urls