from rest_framework.viewsets import ViewSet
from rest_framework.response import  Response
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated,IsAdminUser,IsAuthenticatedOrReadOnly

class ExampleAPIView(ViewSet):
    """权限组件的配置使用"""
    permission_classes = [AllowAny]
    @action(methods=["get"],detail=False)
    def auth(self,request):
        return Response("ok")

    @action(methods=["get"], detail=False)
    def login(self,request):
        return Response("登录页面")

from rest_framework.permissions import BasePermission
class ConstomPermission(BasePermission):
    def has_permission(self, request, view):
        if request.user and request.user.username == "xiaoming":
            return True

class Example2APIView(ViewSet):
    """自定义权限"""
    permission_classes = [ConstomPermission]
    @action(methods=["get"],detail=False)
    def auth(self,request):
        return Response("ok")

from rest_framework.throttling import UserRateThrottle,AnonRateThrottle,ScopedRateThrottle
class Example3APIView(ViewSet):
    """局部配置限流"""
    # throttle_classes = [UserRateThrottle,AnonRateThrottle]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "python30"
    @action(methods = ["get"], detail=False)
    def get(self, request):
        return Response("ok")

from students.models import Student
from rest_framework.viewsets import GenericViewSet
from students.serializers import StudentModelSerializer
from rest_framework.mixins import ListModelMixin
class Example4APIView(GenericViewSet,ListModelMixin):
    """过滤配置"""
    queryset = Student.objects.all()
    serializer_class = StudentModelSerializer
    filter_fields = ["sex","age"]

from rest_framework.filters import OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend
class Example5APIView(GenericViewSet,ListModelMixin):
    """排序配置"""
    queryset = Student.objects.all()
    serializer_class = StudentModelSerializer
    filter_backends = [OrderingFilter,DjangoFilterBackend]
    ordering_fields = ["id","age"]
    filter_fields = ["sex", "age"]

"""偏移量分页器 LimitOffsetPagination"""
# www.xxx.com?limit=10&offset=0
# www.xxx.com?limit=10&offset=10
# www.xxx.com?limit=10&offset=20
# www.xxx.com?limit=10&offset=30
# www.xxx.com?limit=10&offset=40
from rest_framework.pagination import LimitOffsetPagination
class MyPage(LimitOffsetPagination):
    default_limit = 3
    limit_query_param = "limit"
    max_limit = 5
    offset_query_param = "offset"
"""页码分页器 PageNumberPagination"""
# www.xxx.com?size=10&page=1
# www.xxx.com?size=10&page=2
# www.xxx.com?size=10&page=3
# www.xxx.com?size=10&page=4
# www.xxx.com?size=10&page=5
from rest_framework.pagination import PageNumberPagination
class MyNumPage(PageNumberPagination):
    page_size = 3
    max_page_size = 5
    page_size_query_param = "s"
    page_query_param = "p"

class Example6APIView(GenericViewSet,ListModelMixin):
    """分页配置"""
    queryset = Student.objects.all()
    serializer_class = StudentModelSerializer
    pagination_class = MyNumPage

class Example7APIView(ViewSet):
    """分页配置"""
    @action(methods=["get"],detail=False)
    def list(self,request):
        10/0
        return Response("ok")