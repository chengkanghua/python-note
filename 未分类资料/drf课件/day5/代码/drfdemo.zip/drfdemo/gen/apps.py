from django.apps import AppConfig


class GenConfig(AppConfig):
    name = 'gen'
