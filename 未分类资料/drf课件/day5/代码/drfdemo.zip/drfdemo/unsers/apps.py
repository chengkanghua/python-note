from django.apps import AppConfig


class UnsersConfig(AppConfig):
    name = 'unsers'
