from rest_framework import serializers
from students.models import Student
# 字段验证函数[只能用于验证一个字段数据]
def check_class_num(data):
    if data == "404":
        raise serializers.ValidationError("对不起,没有404这样的班级")

    # 一定要返回数据!!!否则丢失了.
    return data

class StudentSerializer(serializers.Serializer):
    # 当字段设置为read_only=True,则当前字段只会在序列化阶段被使用,在反序列化时被忽略
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=20,required=True)
    age  = serializers.IntegerField(max_value=120, required=True)
    sex  = serializers.BooleanField(default=1)
    class_num = serializers.CharField(required=True, validators=[check_class_num])
    description = serializers.CharField(allow_null=True,allow_blank=True)

    # 字段验证方法
    # validate()         # 验证所有字段
    # validate_字段名()   # 验证单个字段

    def validate(self, attrs):
        if attrs.get("age") > 60 and attrs.get("sex") == 1:
            raise serializers.ValidationError("对不起,您的年级太大了!")

        # 注意,每次验证完成以后必须有结果返回!否则数据就会丢失
        return attrs

    def validate_name(self, attr):
        if attr == "老王":
            raise serializers.ValidationError("对不起,您的年级太高了.")
        return attr

    def create(self, validated_data):
        """添加数据"""
        # create(**validated_data)  --->  create(name=xxxx,age=1323)
        ret = Student.objects.create(**validated_data)
        # 把添加的结果返回给函数调用处
        return ret

    def update(self, instance, validated_data):
        """更新数据"""
        # instance.name = validated_data.get("name")
        # instance.age = validated_data.get("age")
        # instance.sex = validated_data.get("sex")
        # instance.class_num = validated_data.get("class_num")
        # instance.description = validated_data.get("description")

        for key,value in validated_data.items():
            setattr(instance,key,value)

        instance.save()
        return instance

class StudentModelSerializer(serializers.ModelSerializer):
    """学生模型类序列化器"""
    # 字段声明
    token = serializers.CharField(read_only=True, default="abc") # 序列化器中也可以转换自定义的字段
    # 模型声明
    class Meta:
        model = Student
        fields = ["id","name","age","sex","token"]
        # fields = "__all__" # 调用模型所有字段
        # read_only_fields 表示设置模型中那些字段属于只读类型的,对于不在模型中字段无效
        read_only_fields = ["id"]
        # 额外参数选项
        extra_kwargs = {
            "token":{"read_only":True},
            "age":{"min_value":1,"max_value":100},
        }
    # 验证方法

    # 数据库操作方法


