from rest_framework.views import exception_handler as drf_exception_handler
from django.db import DatabaseError
from rest_framework.response import Response
from rest_framework import status
def custom_exception_handler(exc, context):
    """
    自定义异常处理函数
    :param exc: 发生异常的异常对象
    :param context: 异常发生时的执行上下文,就是异常发生时的环境信息
    :return: 响应对象或者None
    """
    # 先让drf进行异常判断
    response = drf_exception_handler(exc, context)

    if response is None:
        view = context["view"]
        if isinstance(exc, DatabaseError):
            print('数据库报错，[%s]: %s' % (view, exc))
            return Response({"error": "服务器内部错误!", "errno": 10001}, status=status.HTTP_507_INSUFFICIENT_STORAGE)
        elif isinstance(exc, ZeroDivisionError):
            print("0不能作为除数")
            return Response({"error": "0不能作为除数!", "errno": 10002}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    return response