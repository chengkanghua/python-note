import xadmin
from xadmin import views

class BaseSetting(object):
    """xadmin的基本配置"""
    enable_themes = True  # 开启主题切换功能
    use_bootswatch = True

xadmin.site.register(views.BaseAdminView, BaseSetting)

class GlobalSettings(object):
    """xadmin的全局配置"""
    site_title = "路飞学城"  # 设置站点标题
    site_footer = "路飞学城有限公司"  # 设置站点的页脚
    menu_style = "accordion"  # 设置菜单折叠

xadmin.site.register(views.CommAdminView, GlobalSettings)

from .models import Student
class StudentModelAdmin(object):
    list_display = ['id', 'name', 'sex', 'age']
    search_fields = ['id', 'name']
    list_filter = ['class_num']
    list_editable = ["name","age"] # 允许直接在列表页中进行编辑的字段
    show_detail_fields = ["name"]  # 点击指定字段,允许查看当前数据所有内容
    refresh_times = [2,5,10,30,60] # 指定列表页定时刷新时间[单位:秒]
    # list_export = ['xls', 'json']
    show_bookmarks = True

    data_charts = {
        "order_amount": {
            'title': '学生年龄段',
            "x-field": "id",
            "y-field": ('age','name'),
            "order": ('id',)
        },
        #    支持生成多个不同的图表
        #    "order_amount": {
        #      'title': '图书发布日期表',
        #      "x-field": "bpub_date",
        #      "y-field": ('btitle',),
        #      "order": ('id',)
        #    },
    }

xadmin.site.register(Student,StudentModelAdmin)