from django.contrib import admin
from .models import Student

# Register your models here.
class StudentModelAdmin(admin.ModelAdmin):
    """学生模型管理类"""
    # 列表页配置项[列表]
    list_display = ["id","name","sex","age","my_born"] # 列表页显示字段
    ordering = ["-age",'-id'] # 默认排序字段
    actions_on_bottom = True  # 下方控制栏是否显示,默认False表示隐藏
    actions_on_top = True    # 上方控制栏是否显示,默认False表示隐藏
    list_filter = ["class_num","age"]  # 过滤器,按指定字段的不同值来进行展示
    search_fields = ["name","age"]  # 搜索内容,在列表中指定搜索内容

    # 给自定义字段设置描述信息或者赋值
    def my_born(self, obj):
        return str(obj.born)+"年"

    my_born.admin_order_field = "age"  # 自定义字段点击时使用哪个字段作为排序条件
    my_born.short_description = "出生年份"

    # date_hierarchy = 'age'  # 按指定时间字段的不同值来进行选项排列

    # 详情页配置项[编辑,添加]
    # fields = ['name', 'class_num', "description"] # 配置添加页和编辑页的表单字段
    readonly_fields = ["name"]


    # 字段分组显示
    fieldsets = (
        ("A组", {
            'fields': ('age','name', 'sex')
        }),
        ('B组', {
            'classes': ('collapse',),  # 折叠样式
            'fields': ('class_num',),
        }),
        ('C组',{
            'classes': ["collapse"],
            'fields': ['description']
        })
    )

    def delete_model(self, request, obj):
        """当站点删除当前模型时执行的钩子方法"""
        print("有人删除了模型信息[添加/修改]")

        # raise Exception("无法删除") # 阻止删除
        return super().delete_model(request, obj) # 继续删除

    def save_model(self, request, obj, form, change):
        print("有人修改了模型信息[添加/修改]")
        # 区分添加和修改? obj是否有id
        print(obj.id)
        return super().save_model(request, obj, form, change)

admin.site.register(Student,StudentModelAdmin)