from django.apps import AppConfig


class SersConfig(AppConfig):
    name = 'sers'
