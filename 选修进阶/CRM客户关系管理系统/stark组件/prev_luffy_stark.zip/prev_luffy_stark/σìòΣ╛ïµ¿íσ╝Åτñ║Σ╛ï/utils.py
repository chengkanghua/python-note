#!/usr/bin/env python
# -*- coding:utf-8 -*-


class AdminSite(object):
    pass


site = AdminSite() # 为AdminSite类创建了一个对象（实例）
