#!/usr/bin/env python
# -*- coding:utf-8 -*-
import utils
utils.site.name = '武沛齐'
import commons

"""
在Python中，如果已经导入过的文件再次被重新导入时候，python不会再重新解释一遍，而是选择从内存中直接将原来导入的值拿来用。
"""