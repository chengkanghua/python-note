#!/usr/bin/env python
# -*- coding:utf-8 -*-
import utils

print(utils.site.name)
