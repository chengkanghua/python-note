#!/usr/bin/env python
# -*- coding:utf-8 -*-
from luffy import site

site._registry.append('app01')
