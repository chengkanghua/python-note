from flask import Flask, current_app, g


app = Flask(__name__)

app.config["SECRET_KEY"] = "my secret key"

@app.route("/")
def index():
    print(app == current_app)  # current_app就是app应用实例对象在视图中的本地代理对象
    print(g)  # 全局数据存储对象，用于保存服务端存储的全局变量数据[可以理解为用户级别的全局变量存储对象]
    t1()
    t2()
    print(current_app.config)
    return "ok"

def t1():
    # 存储数据
    g.user_id = 100

def t2():
    # 提取数据
    print(g.user_id)

if __name__ == '__main__':
    # print(app)
    # with app.app_context(): # 构建一个应用上下文环境
    #     print(current_app)
    # print(request) # 没有发生客户端请求时，调用request会超出请求上下文的使用范围！
    app.run(host="0.0.0.0", port=5000, debug=True)
