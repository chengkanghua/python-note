from flask import Flask, request, abort


app = Flask(__name__)


@app.route("/")
def index():
    password = request.args.get("password")
    if password != "123456":
        # 主动抛出异常！
        # abort的第一个参数：表示本次抛出的HTTP异常状态码，后续其他参数，表示错误相关的提示内容。
        abort(400)
    return "ok"


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
