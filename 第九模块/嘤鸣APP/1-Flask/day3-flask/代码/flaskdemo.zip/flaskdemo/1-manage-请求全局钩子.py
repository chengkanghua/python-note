from flask import Flask


app = Flask(__name__)

# @app.before_first_request
def before_first_request():
    """
    当项目启动以后，首次被客户端访问时自动执行被 @app.before_first_request 所装饰的函数
    用于项目初始化
    可以编写一些初始化项目的代码，例如，数据库初始化，加载一些可以延后引入的全局配置
    :return:
    """
    print("before_first_request执行了!!!!")


app.before_first_request_funcs.append(before_first_request)


@app.before_request
def before_request():
    """
    每次客户端访问，视图执行之前，都会自动执行被 @app.before_request 所装饰的函数
    用于每次视图访问之前的公共逻辑代码的运行[身份认证，权限判断]
    :return:
    """
    print("before_request执行了！！！！")


@app.after_request
def after_request(response):
    """
        每次客户端访问，视图执行之后，都会自动执行被 @app.after_request 所装饰的函数
    用于每次视图访问之后的公共逻辑代码的运行[返回结果的加工，格式转换，日志记录]
    :param response: 本次视图执行的响应对象
    :return:
    """
    print("after_request执行了！！！！！")
    response.headers["Content-Type"] = "application/json"
    response.headers["Company"] = "python.Edu..."
    return response


@app.teardown_request
def teardown_request(exc):
    """
    每次客户端访问，视图执行报错以后，会自动执行 @app.teardown_request 所装饰的函数
    注意：在flask2.2之前，只有在DEBUG=False时，才会自动执行 @app.teardown_request 所装饰的函数
    :param exc: 本次出现的异常实例对象
    :return:
    """
    print("teardown_request执行了！！！！！")
    print(f"错误提示：{exc}")  # 异常提示


@app.route("/")
def index():
    print("----------------视图执行了！！！！--------------")
    return "ok"


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
