from flask import Flask, request, session


app = Flask(__name__)

app.config["SECRET_KEY"] = "my secret key"

def test():
    print(request) # 请求上下文所提供的对象[request或session]只能被视图直接或间接调用！

@app.route("/")
def index():
    print(request)
    print(session)
    test()
    return "ok"


if __name__ == '__main__':
    # print(request) # 没有发生客户端请求时，调用request会超出请求上下文的使用范围！
    app.run(host="0.0.0.0", port=5000, debug=True)
