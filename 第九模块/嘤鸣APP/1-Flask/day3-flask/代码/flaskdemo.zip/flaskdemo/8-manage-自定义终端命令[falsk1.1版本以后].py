import click
from flask import Flask


app = Flask(__name__)


@app.cli.command("faker")  # 假设这个用于生成测试数据
@click.argument("data", type=str, default="user") # 位置参数
@click.argument("position", type=str, default="mysql") # 位置参数
@click.option('-n', '--number', 'number', type=int, default=1, help='生成的数据量.')  # 选项参数
def faker_command(data, position, number):
    """
    命令的说明文档：添加测试信息
    """
    print("添加测试信息")
    print(f"数据类型：data={data}")
    print(f"数据类型：position={position}")
    print(f"生成数量：number={number}")


@app.route("/")
def index():
    return "ok"

if __name__ == '__main__':
    app.run()
