# 1. 导入flask核心类
from flask import Flask

# 2. 初始化web应用程序的实例对象
app = Flask(__name__)

@app.route("/")
def index():
    return "hello, flask"

if __name__ == '__main__':
    # 3. 运行flask提供的测试web服务器程序
    print(app.config)
    app.run(host="0.0.0.0", port=5000)