import pymongo
from urllib.parse import quote_plus

if __name__ == '__main__':
    # 连接数据库
    username = quote_plus("root")
    password = quote_plus("123456")
    database = quote_plus("admin")
    mongo = pymongo.MongoClient(f"mongodb://{username}:{password}@127.0.0.1:27017/{database}")
    # 切换或新建数据库
    db = mongo["test"]
    # 切换或新建数据集
    users = db["users"]

    """添加文档"""
    # # 添加一个文档
    # document = {"name": "xiaoming", "mobile": "13012345678", "age": 16}
    # ret = users.insert_one(document)
    # print(ret.inserted_id)  # 返回新增文档的主键ID
    #
    #
    # # 添加多个文档
    # document_list = [
    #     {"name": "xiaoming", "mobile": "13033345678", "age": 17},
    #     {"name": "xiaohong", "mobile": "13044345678", "age": 18},
    #     {"name": "xiaohei", "mobile": "13612345678", "age": 18},
    # ]
    # ret = users.insert_many(document_list)
    # print(ret.inserted_ids)  # 返回新增文档的主键ID列表


    """删除文档"""
    # # 删除一篇文档
    # filter = {"name":"xiaoming"}
    # ret = users.delete_one(filter)
    # print(ret.deleted_count) # 返回删除文档的数量
    #
    # # 删除多篇文档
    # filter = {"name": "xiaohong"}
    # ret = users.delete_many(filter)
    # print(ret.deleted_count) # 返回删除文档的数量

    # # 按指定条件删除多个文档
    # filter = {"age": {"$gte": 17}}  # age >= 17
    # ret = users.delete_many(filter)
    # print(ret.deleted_count)  # 返回删除文档的数量


    """更新文档"""
    # # 更新一个文档
    # filter = {"name": "xiaoming"}
    # update = {"$set": {"name": "xiaohong"}, "$inc": {"age": -3}}
    # ret = users.update_one(filter=filter, update=update)
    # print(ret.modified_count)  # 返回更新文档的数量

    # # 更新多个文档
    # filter = {"name": "xiaohong"}
    # update = {"$set": {"sex": True}}
    # ret = users.update_many(filter=filter, update=update)
    # print(ret.modified_count)  # 返回更新文档的数量

    # # 把满足条件的一个文档进行替换
    # filter = {"name": "xiaoming"}
    # replace = {"name": "xiaolan", "age": 16, "sex": False} # 因为是直接替换文档，所以不需要指定更新运算符
    # ret = users.replace_one(filter, replace)
    # print(ret.modified_count)  # 返回替换文档的数量


    """查询文档"""
    # # 获取整个集合所有的文档数据
    # orders = db["orders"]
    # ducument_list = orders.find()
    # for document in ducument_list:
    #     print(document)

    # # 获取集合中第一个文档
    # orders = db["orders"]
    # document = orders.find_one()
    # print(document)
    # print(document.get("order_number"))  # 获取文档中的任意数据
    # print(document.get("items"))  # 获取文档中的任意数据
    # print(document["items"][0])  # 获取文档中的任意数据
    # print(document["items"][0]["price"])  # 获取文档中的任意数据

    # # 投影显示字段
    # document = users.find_one({}, {"_id": 0})
    # print(document)
    #
    # document = users.find_one({}, {"_id": 0, "name": 1, "age": 1})
    # print(document)


    # 按条件查询多条数据
    # filter = {"age": 18}
    # document_list = users.find(filter)
    # for document in document_list:
    #     print(document)

    # # 比较运算符
    # filter = {"age": {"$gt":17}}
    # document_list = users.find(filter)
    # for document in document_list:
    #     print(document)


    # # 结果排序，单字段排序
    # filter = {"age": {"$lt": 32}}
    # #  pymongo.ASCENDING 就是 -1 ，表示升序， 从小到大
    # #  pymongo.DESCENDING 就是 1 ，表示降序， 从大到小
    # document_list = users.find(filter).sort("age", pymongo.DESCENDING)
    # print(list(document_list))

    # # 结果排序，多字段排序
    # filter = {"age": {"$lte": 34}}
    # order = [("age", pymongo.DESCENDING), ("_id", pymongo.ASCENDING)]
    # document_list = users.find(filter).sort(order)
    # print(list(document_list))


    # # 限制查询结果数量
    # document_list = users.find().limit(3)
    # print(list(document_list))

    # # 偏移、跳过
    # #	skip(int)
    # document_list = users.find().limit(3).skip(3)  # 从第3篇文档开始获取3篇文档
    # print(list(document_list))

    # # 自定义条件函数
    # document_list = users.find({"$where": "this.age==18"})
    # print(list(document_list))

    ret = db.command("buildinfo")
    print(ret)