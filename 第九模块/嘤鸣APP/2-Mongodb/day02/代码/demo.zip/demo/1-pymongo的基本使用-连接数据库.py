import pymongo
from urllib.parse import quote_plus

if __name__ == '__main__':
    # # 无密码连接mongo[如果mongo没有开启用户访问控制机制的情况下，可以使用]
    # mongo = pymongo.MongoClient("mongodb://127.0.0.1:27017")
    # ret = mongo.list_databases()


    # 有密码连接
    username = quote_plus("root")
    password = quote_plus("123456")
    database = quote_plus("admin")
    mongo = pymongo.MongoClient(f"mongodb://{username}:{password}@127.0.0.1:27017/{database}")
    print(mongo.list_databases()) # 列出当前账户可操作的所有数据库
    # 切换操作的数据库
    db = mongo["test"]
    print(db)
    print(db.list_collection_names())

    # 列出当前数据库下的所有集合
    print(db.list_collections())
    # 获取当前数据库下的指定集合操作对象
    users_collection = db["orders"]
    print(users_collection)
    # 统计当前集合下所有的文档数量
    count = users_collection.count_documents({})
    print(count)

    # 删除集合
    doc_collection = db["doc"]
    doc_collection.drop()



