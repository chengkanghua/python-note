"""生产配置"""
# 调试模式
DEBUG: bool = False
# 语言
LANGUAGE: str = "zh_hans"
# 时区
TZ: str = "UTC"
