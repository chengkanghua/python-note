from datetime import datetime

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow

app = Flask(__name__)
app.config["DEBUG"] = True
app.config["SQLALCHEMY_DATABASE_URI"]="mysql://root:123@127.0.0.1:3306/yingming?charset=utf8mb4"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ECHO"] = True

db = SQLAlchemy()
db.init_app(app)

ma = Marshmallow()
ma.init_app(app)


"""模型"""
class User(db.Model):
    __tablename__ = "desc_user"
    id = db.Column(db.Integer, primary_key=True, comment="主键ID")
    username = db.Column(db.String(255), index=True, comment="用户名")
    password = db.Column(db.String(255), comment="登录密码")
    mobile = db.Column(db.String(15), index=True, comment="手机号码")
    sex = db.Column(db.Boolean, default=True, comment="性别")
    email = db.Column(db.String(255), index=True, comment="邮箱")
    created_time = db.Column(db.DateTime, default=datetime.now, comment="创建时间")
    updated_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")

    def __repr__(self):
        return "<%s: %s>" % (self.__class__.__name__, self.username)


"""序列化器"""

from marshmallow import Schema, fields


class UserSchema(Schema):
    username = fields.String()
    mobile = fields.String()
    sex = fields.Boolean()
    email = fields.Email()
    created_time = fields.DateTime()
    updated_time = fields.DateTime()



@app.route("/1")
def index1():
    """序列化一个对象成字典或字符串"""
    # 模拟从数据库中读取出来的模型类
    user = User(
        username="xiaoming",
        mobile="13312345677",
        sex=True,
        email="133123456@qq.com",
        created_time=datetime.now(),
        updated_time=datetime.now()
    )

    db.session.add(user)
    db.session.commit()
    print(user)

    # 序列化成一个字典
    us = UserSchema()
    result = us.dump(user)
    print(result, type(result))

    # 序列化器成一个字符串[符合json语法]
    result = us.dumps(user)
    print(result, type(result))

    # 如果要序列化多个模型对象，可以使用many=True
    result = us.dump([user,user,user], many=True)
    print(result)
    result = us.dumps([user,user,user], many=True)
    print(result)
    return "ok"

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5555)