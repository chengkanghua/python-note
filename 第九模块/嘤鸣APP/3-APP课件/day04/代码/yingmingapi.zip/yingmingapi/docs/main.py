from datetime import datetime

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow

app = Flask(__name__)
app.config["DEBUG"] = True
app.config["SQLALCHEMY_DATABASE_URI"]="mysql://root:123@127.0.0.1:3306/yingming?charset=utf8mb4"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ECHO"] = True

db = SQLAlchemy()
db.init_app(app)

ma = Marshmallow()
ma.init_app(app)


"""模仿ORM的模型"""
class Model(object):
    pass

class User(Model):
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.created_at = datetime.now()
        self.books = []    # 用来代替MySQL中的外检关系，实现1对多或多对多
        self.friends = []  # 用来代替MySQL中的外检关系，实现自关联


class Book(Model):
    def __init__(self, title, author):
        self.title = title
        self.author = author  # 用来代替MySQL中的外键关系，1对1

"""序列化器"""
from marshmallow import Schema, fields


class UserSchema(Schema):
    """用户的序列化器"""
    name = fields.String()
    email = fields.Email()
    """1对多，多对多"""
    # 在fields.Nested外围包裹一个List列表字段，则可以返回多个结果了。exclude表示排除
    # books = fields.List(fields.Nested(lambda: BookSchema(exclude=["author"])))
    # 简写方式:
    books = fields.Nested(lambda : BookSchema(many=True, exclude=["author"]))
    """自关联"""
    # 自关联就是一个模型中既存在主键关系，也存在外键关系的情况
    # 方式1：使用自身"self"作为外键的方式，并可以指定序列化模型的多个字段
    # friends = fields.Nested(lambda: "self", only=("name", "email", "books"), many=True)
    # 方式2：使用Pluck字段可以用单个值来替换嵌套的数据，只可以得到模型的单个字段值
    friends = fields.Pluck(lambda: "self", "name", many=True)

class BookSchema(Schema):
    """图书的序列化器"""
    title = fields.String()
    author = fields.Nested(lambda: UserSchema(exclude=["books"]))

@app.route("/1")
def index1():
    """构造器嵌套使用"""
    # 假设根据当前作者，查找对应的作者发布的图书列表
    user0 = User(name="南派三叔", email="sanshu@163.com")

    book1 = Book(title="盗墓笔记1", author=user0)
    book2 = Book(title="盗墓笔记2", author=user0)
    book3 = Book(title="盗墓笔记3", author=user0)
    user0.books = [book1, book2, book3]

    us = UserSchema()
    result = us.dump(user0)
    print(result)

    bs = BookSchema()
    result = bs.dump([book1, book2, book3], many=True)
    print(result)

    return "ok"


@app.route("/2")
def index2():
    """自关联"""
    user0 = User(name="南派三叔", email="sanshu@163.com")
    user1 = User(name="刘慈欣", email="sanshu@163.com")
    user2 = User(name="天下霸唱", email="sanshu@163.com")
    user0.friends = [user1, user2]

    us = UserSchema()
    result = us.dump(user0)
    print(result)

    return "ok"

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5555)