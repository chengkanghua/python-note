from flask import Flask, request, redirect, url_for, Response


app = Flask(__name__)

@app.route("/")
def index():
    """自定义响应头"""
    return "hello, flask", 201, {"Company": "flask.edu"}


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
