import json

from flask import Flask, request


app = Flask(__name__)

@app.route("/header", methods=["get", "post", "put", "patch","delete"])
def header():
    """
    获取请求头等其他请求信息
    :return:
    """
    # # 获取请求头所有信息
    # print(request.headers, type(request.headers))
    #
    # """
    # 获取单个请求头信息
    # """
    # # 基于get使用请求头原始属性名获取， User-Agent 客户端的网络代理工具名称
    # print(request.headers.get("User-Agent"))  # PostmanRuntime/7.26.10
    # # 把原始属性名转换成小写下划线格式来获取
    # print(request.user_agent)   # PostmanRuntime/7.26.10
    #
    # # 获取本次客户端请求的服务端地址
    # print(request.host)  # 127.0.0.1:5000
    #
    # # 获取本次客户端请求提交的数据格式
    # print(request.content_type)  # multipart/form-data;
    #
    # # 获取本次客户端请求的uri路径
    # print(request.path)  # /header
    # # 获取本次客户端请求完整url地址
    # print(request.url)   # http://127.0.0.1:5000/header
    # # 获取本次客户端请求的服务端域名
    # print(request.root_url)  # http://127.0.0.1:5000/
    #
    # # 获取本次客户端的Http请求方法或请求动作
    # print(request.method)  # POST
    #
    # # 获取本次客户端的IP地址
    # print(request.remote_addr)  # 127.0.0.1
    #
    # # 获取本次客户端获取到的服务端信息
    # print(request.server)  # ('0.0.0.0', 5000)

    # 获取本次客户端请求时，服务端的系统系统环境变量信息
    # print(request.environ)

    """
    获取自定义请求头
    """
    print(request.headers.get("company"))  # flask.edu

    return "hello, flask"


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
