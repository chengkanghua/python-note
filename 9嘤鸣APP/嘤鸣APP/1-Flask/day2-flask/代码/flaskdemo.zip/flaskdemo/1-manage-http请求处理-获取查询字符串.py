from flask import Flask, request
from urllib.parse import parse_qs


app = Flask(__name__)


@app.route("/qs")
def qs():
    """
    获取客户端请求的查询字符串参数
    :return:
    """
    """
    请求url：http://127.0.0.1:5000/qs?user=xiaoming&age=16
    """
    # 获取原始的查询字符串参数，格式：bytes
    # print(request.query_string)
    # b'user=xiaoming&age=16'

    # # 针对原始的查询字符串参数，转换成字典格式
    # query_string = parse_qs(request.query_string.decode())
    # print(query_string)  # {'user': ['xiaoming'], 'age': ['16']}

    # # 获取参数值
    # print(query_string["user"][0])


    # # 获取查询字符串参数，格式：ImmutableMultiDict
    # print(request.args)
    # # ImmutableMultiDict([('user', 'xiaoming'), ('age', '16')])

    # # 获取单个参数值
    # print(request.args["user"])
    # print(request.args["age"])
    # print(request.args.get("age"))


    """
    请求url：http://127.0.0.1:5000/qs?user=xiaoming&fav=shopping&fav=coding&fav=rap
    """
    # print(request.args["user"]) # 'xiaoming'
    # print(request.args["fav"])  # 'shopping'
    # print(request.args.get("user")) # 'xiaoming'

    print(request.args.getlist("fav"))  # ['shopping', 'coding', 'rap']

    return "hello, flask"


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
