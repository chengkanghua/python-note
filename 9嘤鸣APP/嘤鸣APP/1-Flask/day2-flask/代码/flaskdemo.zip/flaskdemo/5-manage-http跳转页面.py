from flask import Flask, request, redirect, url_for, Response


app = Flask(__name__)


@app.route("/user")
def index():
    if request.args.get("token"):
        return "个人中心"

    # 跳转页面到登录视图中
    # redirect("url地址") # 控制页面跳转到任意路径下
    # return redirect("/login")

    # 跳转页面到其他视图中
    url = url_for("login")  # url_for("视图名称")
    print(app.url_map)  # 路由列表，整个flask站点中所有的url地址和视图的映射关系都在这个属性里面
    print(url)
    return redirect(url)


@app.route("/login")
def login():
    return "登录视图"


@app.route("/jump")
def jump():
    """跳转页面到站外"""
    """
    301: 永久重定向，页面已经没有了，站点没有了，永久转移了。[域名映射-->域名解析]
    302：临时重定向，一般验证失败、访问需要权限的页面进行登录跳转时，都是属于临时跳转。
    """
    # response = redirect("https://www.qq.com", 302)
    # print(response)
    # return response

    # 底层原理
    response = Response("", 302, {"Location": "https://www.163.com"})
    return response


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
