from flask import Flask, session, request, make_response, redirect


app = Flask(__name__)

# 因为flask中的session是基于cookie加密实现的，所以使用之前必须设置SECRET_KEY选项
app.config["SECRET_KEY"] = "dskafmdfmem2w4m234mfmvdfmasdkqaso3423"


@app.route("/set_session")
def set_session():
    """设置session"""
    session["username"] = "xiaoming"
    session["user_id"] = 31
    session["data"] = [1, 2, 3, 5, "AAAA"]

    return "set_session"


@app.route("/get_session")
def get_session():
    """读取session"""
    print(f'username={session.get("username")}')
    print(f'user_id={session.get("user_id")}')
    print(f'data={session.get("data")}')
    return "get_session"


@app.route("/del_session")
def del_session():
    """删除session"""
    session.pop("username")
    session.pop("data")
    return "del_session"


@app.route("/login", methods=["get", "post"])
def login():
    """基于session实现登录认证"""
    form = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Title</title>
    </head>
    <body>
      <form action="" method="post">
        账号：<input type="text" name="username"><br><br>
        密码：<input type="password" name="password"><br><br>
        <input type="submit" value="登录">
      </form>
    </body>
    </html>
    """
    if request.method == "GET":
        return make_response(form)

    """接收客户端POST提交表单数据"""
    # 暂时不使用数据库，我们模拟用户身份判断代码
    username = request.form.get("username")
    password = request.form.get("password")
    if username == "root" and password == "123456":
        """认证通过"""
        # 基于session保存登录状态
        session["username"] = "root"
        session["user_id"]  = "root"
        response = make_response("登录成功！")
        return response
    else:
        """认证失败"""
        # 返回GET请求的login登录页面
        response = redirect("/login")
        return response


@app.route("/user")
def user():
    """在部分需要认证身份的页面中，基于session判断用户登录状态"""
    if not session.get("username"):
        response = redirect("/login")
        return response

    return "个人中心的信息展示"


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
