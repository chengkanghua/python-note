import json
from flask import Flask, make_response, Response, jsonify


app = Flask(__name__)


@app.route("/")
def index():
    """响应HTML文本，并设置响应状态码"""
    # return "<h1>hello, flask</h1>", 400

    """通过make_response返回Response对象"""
    # response = make_response("<h1>hello, flask</h1>", 201)
    # print(response)
    # return response

    """通过Response返回Response对象"""
    response = Response("<h1>hello, flask</h1>", 201)
    return response


@app.route("/jsonapi")
def jsonapi():
    """响应json数据[原生写法]"""
    data = {"name": "xiaoming", "age": 16}
    # return json.dumps(data), 200, {"Content-Type": "application/json"}
    # return Response(json.dumps(data), 200, {"Content-Type": "application/json"})

    """响应json数据[jsonify]"""
    data = {"name": "xiaoming", "age": 16}
    response = jsonify(data)
    print(response)
    return response

@app.route("/img")
def img():
    """响应图片格式给客户端"""
    with open("avatar.png", "rb") as f:
        data = f.read()
    return data, 200, {"Content-Type": "image/png"}  # MIME类型

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
