from flask import Flask, request, redirect, url_for, Response


app = Flask(__name__)


@app.route("/mobile/<int:mobile>")
def sms(mobile):
    """发送短信"""
    return f"发送短信给{mobile}"


@app.route("/info")
def info():

    # 跳转页面到一个具有路由参数的视图中
    # return redirect("/sms/13012345678")

    url = url_for("sms", mobile="13012345677")
    print(url)  # /sms/13012345677
    return redirect(url)


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
