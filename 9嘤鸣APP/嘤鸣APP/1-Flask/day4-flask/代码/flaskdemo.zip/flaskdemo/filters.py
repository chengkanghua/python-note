def do_fixed(data, length=2):
    return f"%.{length}f" % data

def do_yuan(data):
    return f"{data}元"

FILTERS = {
    "fixed": do_fixed,
    "yuan": do_yuan,
}

if __name__ == '__main__':
    ret = do_fixed(10)
    print(ret)