from flask import url_for, render_template
# 光写视图，不用写路由
def login():
    title = "用户登录视图"
    return render_template("login.html", **locals())

def register():
    return f"用户注册视图，登录视图的url地址：{url_for('users.login')}"