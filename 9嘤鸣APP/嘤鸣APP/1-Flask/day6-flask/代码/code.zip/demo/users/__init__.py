from flask import Blueprint
from . import views

# 等同于 app = Flask(__name__)，只是这里并非一个独立的flask项目，
# 所以需要在第一个参数中，指定蓝图名称，其他参数与之前实例化app应用对象是一样的。
users_blueprint = Blueprint("users", __name__, static_folder="static", template_folder="templates")

# 把蓝图下的视图与蓝图下的路由进行绑定
users_blueprint.add_url_rule(rule="/login", view_func=views.login)
users_blueprint.add_url_rule(rule="/register", view_func=views.register)

print(users_blueprint.deferred_functions)