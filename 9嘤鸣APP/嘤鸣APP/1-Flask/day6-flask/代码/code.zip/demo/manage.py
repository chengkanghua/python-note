from flask import Flask

app = Flask(__name__)

# 注册蓝图
from users import users_blueprint
app.register_blueprint(blueprint=users_blueprint, url_prefix="/users")

if __name__ == '__main__':
    print(app.url_map)
    app.run(debug=True)