import db
from datetime import datetime


# 1. 创建一个与数据库对应的模型类对象
class Student(db.Model):
    """学生表模型"""
    __tablename__ = "tb_student"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20))
    sex = db.Column(db.Boolean, default=True)
    age = db.Column(db.SmallInteger)
    classes = db.Column("class", db.SMALLINT)
    description = db.Column(db.Text)
    status = db.Column(db.Boolean, default=1)
    addtime = db.Column(db.DateTime, default=datetime.now)
    orders = db.Column(db.SMALLINT, default=1)

    def __repr__(self):
        return f"<{self.__class__.__name__} {self.name}>"


if __name__ == '__main__':
    """过滤条件查询"""
    """
    filter_by - 精确查询
    filter_by支持值相等=号操作，不能使用大于、小于或不等于的操作一律不能使用
    """
    # # 单个字段条件
    # students = db.session.query(Student).filter_by(name="小明1号").all()
    # print(students)

    # # 多个and条件
    # students = db.session.query(Student).filter_by(sex=1, age=18).all()
    # print(students)

    """
    filter - 匹配查询
    支持所有的运算符表达式，比filter精确查询要更强大
    注意：条件表达式中的字段名必须写上模型类名
    filter中的判断相等必须使用==2个等号
    """
    # # 获取查询结果集的所有数据，列表
    # students = db.session.query(Student).filter(Student.age > 17).all()
    # print(students) # [<Student 小明1号>, <Student 小明1号>, <Student 小明3号>, <Student 小明4号>]
    #
    # # 获取查询结果集的第一条数据，模型对象
    # students = db.session.query(Student).filter(Student.age < 18).first()
    # print(students) # <Student 小明1号>

    """in运算符"""
    students = db.session.query(Student).filter(Student.id.in_([1, 3, 4])).all()
    print(students) # [<Student 小明1号>, <Student 小明1号>, <Student 小明2号>]

    """多条件表达式"""
    """多个or条件"""
    # from sqlalchemy import or_
    # # 查询302或303班的学生
    # students = db.session.query(Student).filter(or_(Student.classes==303, Student.classes==302)).all()
    # print(students) # [<Student 小明1号>, <Student 小明2号>]

    """多个and条件"""
    # students = db.session.query(Student).filter(Student.age==18, Student.sex==1).all()
    # print(students) # [<Student 小明1号>, <Student 小明3号>]

    # from sqlalchemy import and_
    # students = db.session.query(Student).filter(and_(Student.age == 18, Student.sex == 1)).all()
    # print(students) # [<Student 小明1号>, <Student 小明3号>]

    """and_主要用于与or_一起使用的"""
    # 查询305的18岁男生 或者 305班的17岁女生
    from sqlalchemy import and_, or_
    # students = db.session.query(Student).filter(
    #     or_(
    #         and_(Student.classes==305, Student.age==18, Student.sex==1),
    #         and_(Student.classes==305, Student.age==17, Student.sex==2),
    #     )
    # ).all()

    students = db.session.query(Student).filter(
        and_(
            Student.classes == 305,
            or_(
                and_(Student.age == 18, Student.sex == 1),
                and_(Student.age == 17, Student.sex == 2)
            )
        )
    ).all()

    print(students) # [<Student 小明1号>, <Student 小明4号>]
