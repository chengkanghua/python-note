import db
from datetime import datetime


# 1. 创建一个与数据库对应的模型类对象
class Student(db.Model):
    """学生表模型"""
    __tablename__ = "tb_student"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20))
    sex = db.Column(db.Boolean, default=True)
    age = db.Column(db.SmallInteger)
    classes = db.Column("class", db.SMALLINT)
    description = db.Column(db.Text)
    status = db.Column(db.Boolean, default=1)
    addtime = db.Column(db.DateTime, default=datetime.now)
    orders = db.Column(db.SMALLINT, default=1)

    def __repr__(self):
        return f"<{self.__class__.__name__} {self.name}>"

    def todict(self):
        return {
            "id": self.id,
            "name": self.name,
            "classes": self.classes,
            "age": self.age,
        }


if __name__ == '__main__':
    """DQL-读取数据"""
    # # 返回游标对象
    # cursor = db.session.execute("select * from tb_student")
    # # # 获取一条结果,mappings方法表示把结果从元组转换成字典
    # student = cursor.mappings().fetchone()
    # print(student)

    # # 获取指定数量结果
    # student_list = cursor.mappings().fetchmany(2)
    # print(student_list)

    # # 获取所有结果
    # student_list = cursor.mappings().fetchall(cursor=)
    # print(student_list)


    """DML-写入数据"""
    sql = "insert into tb_student(name, class, age, sex, description) values(:name, :class, :age, :sex, :description)"
    data = {
        "class": "305",
        "age": 19,
        "name": "xiaohong",
        "sex": 0,
        "description": ".....",
    }

    cursor = db.session.execute(sql, params=data)
    db.session.commit()
    print(cursor.lastrowid)  # 获取最后添加的主键ID
