import db
from datetime import datetime


# 1. 创建一个与数据库对应的模型类对象
class Student(db.Model):
    """学生表模型"""
    __tablename__ = "tb_student"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20))
    sex = db.Column(db.Boolean, default=True)
    age = db.Column(db.SmallInteger)
    classes = db.Column("class", db.SMALLINT)
    description = db.Column(db.Text)
    status = db.Column(db.Boolean, default=1)
    addtime = db.Column(db.DateTime, default=datetime.now)
    orders = db.Column(db.SMALLINT, default=1)

    def __repr__(self):
        return f"<{self.__class__.__name__} {self.name}>"

    def todict(self):
        return {
            "id": self.id,
            "name": self.name
        }


if __name__ == '__main__':
    """更改数据"""
    # 查询要更改的数据[目的为了让ORM实现表记录与模型对象的映射]
    student = db.session.query(Student).get(6)
    student.age = 16
    student.classes = 301
    db.session.commit()
