from typing import List
from application import path


urlpatterns: List = [
    path("/home", "home.urls"),
]