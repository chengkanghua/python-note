def index():
    return "home.index"

def test():
    return "home.test"

