class Game{
	constructor(bg_music){
		// 构造函数
		this.init();
    	this.play_music(bg_music);
	}
	init(){
		// 初始化
		console.log("系统初始化");
    	this.rem();
	}
	print(data){
		// 打印数据
		console.log(JSON.stringify(data));
	}

	rem(){
		// 样式适配[保证在任何尺寸下的手机里面，页面效果保持]
		if(window.innerWidth<1200){
			this.UIWidth = document.documentElement.clientWidth;
			this.UIHeight = document.documentElement.clientHeight;
			document.documentElement.style.fontSize = (0.01*this.UIWidth*3)+"px";
			document.querySelector("#app").style.height=this.UIHeight+"px"
		}
		window.onresize = ()=>{
			if(window.innerWidth<1200){
				this.UIWidth = document.documentElement.clientWidth;
				this.UIHeight = document.documentElement.clientHeight;
				document.documentElement.style.fontSize = (0.01*this.UIWidth*3)+"px";
			}
		}
	}
	stop_music(){
		// 暂停音乐
		this.print("停止")
		document.body.removeChild(this.audio);
	}
	play_music(src){
		// 播放音乐
		this.audio = document.createElement("audio");
		this.source = document.createElement("source");
		this.source.type = "audio/mp3";
		this.audio.autoplay = "autoplay";
		this.source.src=src;
		this.audio.appendChild(this.source);
		document.body.appendChild(this.audio);
		var t = setInterval(()=>{
		if(this.audio.readyState > 0){
			if(this.audio.ended){
			clearInterval(t);
			document.body.removeChild(this.audio);
			}
		}
		},100);
	}
}
