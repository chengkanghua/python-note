from flask import request
from flask.views import MethodView


class Home(MethodView):
    def get(self):
        print(request.method)
        return {"title": "类视图的get代码"}

    def post(self):
        print(request.method)
        return {"title": "类视图的post代码"}

def index():
    return "home.index"

def test():
    return "home.test"


