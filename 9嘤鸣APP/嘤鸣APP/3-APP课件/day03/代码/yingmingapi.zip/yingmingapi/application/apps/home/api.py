from application import jsonrpc
# PEP484规范: 给所有的变量、函数/方法的返回值、参数，必须指定他们的类型
from typing import Union, Any, List, Dict, Optional
from numbers import Real


@jsonrpc.method(name="Home.menu")  # 定义api接口的方法名，相当于定义视图的访问路由
def menu(data0: Any, data1: int,  data2: float, data3: str, data4: Union[int, bool], data5: bool,
         data6: List[Any], data7: List[int], data8: Dict[str, Real], data9: Optional[int] = None) -> List[Any]:
    print(f"data0={data0}, 格式：{type(data0)}")
    print(f"data1={data1}, 格式：{type(data1)}")
    print(f"data2={data2}, 格式：{type(data2)}")
    print(f"data3={data3}, 格式：{type(data3)}")
    print(f"data4={data4}, 格式：{type(data4)}")
    print(f"data5={data5}, 格式：{type(data5)}")
    print(f"data6={data6}, 格式：{type(data6)}")
    print(f"data7={data7}, 格式：{type(data7)}")
    print(f"data8={data8}, 格式：{type(data8)}")
    print(f"data9={data9}, 格式：{type(data9)}")
    message: List[Any] = [
        data0,  # 可以填写任意类型数据
        data1,   # 只能填写整型
        data2,   # 只能填写浮点型
        data3,   # 只能填写字符串
        data4,   #  Union表示联合类型， Union[int, bool]表示只能填写整型或布尔型之间的一种
        data5,  # 只能填写布尔型
        data6,  # List[Any]，只能填写列表数据，列表中的成员可以是任意类型的数据
        data7,  # List[int]，只能填写列表数据，列表中的成员只能是整型，除此之外，还有 List[str]、List[Dict[str, Any]]
        data8,  # Dict[str, Real]，只能填写字典数据，字典中的键必须是字符串，值必须是数值类型[包括整型和浮点型]
        data9,  # Optional[int, str]，Optional表示可选，也就是这个参数可以不填，默认None，也可以填写int类型
    ]
    return message


# jsonrpc的类视图
class Home(object):
    def index(self,num: int)->Dict[str, Union[int, str]]:
        return {
            "errno": 200,
            "errmsg": "ok",
            "data": "hello world!%s" % num
        }

    def list(self)->Dict[str,str]:
        return {
            "data": "hello,list"
        }