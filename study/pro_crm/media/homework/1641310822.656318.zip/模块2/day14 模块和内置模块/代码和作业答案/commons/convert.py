def int_to_string():
    return "你好"
