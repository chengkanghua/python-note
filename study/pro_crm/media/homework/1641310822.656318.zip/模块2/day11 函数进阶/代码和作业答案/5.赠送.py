v1 = 3
v2 = 3

print(id(v1), id(v2))

