def func(data):
    print(data, id(data))  # 武沛齐  140247057684592


v1 = "武沛齐"
print(id(v1))  # 140247057684592

func(v1)
func(v1)
func(v1)
func(v1)
func(v1)
func(v1)
func(v1)
func(v1)
