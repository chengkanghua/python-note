import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
USER_DB_PATH = os.path.join(BASE_DIR, 'db', 'user.txt')

EMAIL = "wptawy@126.com"
EMIAL_SMTP = "smtp.126.com"
EMAIL_PWD = "WIYSAILOVUKPQGHY"
EMAIL_FROM_NAME = "武沛齐"
