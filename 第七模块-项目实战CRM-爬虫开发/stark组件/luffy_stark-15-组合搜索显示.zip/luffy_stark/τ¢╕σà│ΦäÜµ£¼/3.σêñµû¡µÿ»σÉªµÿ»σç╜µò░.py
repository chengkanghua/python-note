#!/usr/bin/env python
# -*- coding:utf-8 -*-
from types import FunctionType


def func(arg):
    pass


print(isinstance('sadf', FunctionType))

#
