from django.views import View
from .serializers import StudentSerializer
from django.http.response import JsonResponse
from students.models import Student
class StudentView(View):
    def get1(self,request):
        # 实例化序列化器创建序列化器对象

        # 参数:
        # instance 模型对象或者模型列表
        # data     进行反序列化阶段使用的数据,数据来自于客户端的提交
        # context  当需要从视图中转发数据到序列化器时,可以使用
        # many     当instance参数为模型列表,则many的值必须是True
        student_list = Student.objects.all()
        print(student_list)
        """打印效果:
        <QuerySet [<Student: 小黑>, <Student: 小白>]>
        """
        serialzier = StudentSerializer(instance=student_list,many=True)
        print(serialzier.data)
        """打印效果:
        [OrderedDict([('name', '小黑')]), OrderedDict([('name', '小白')])]
        OrderedDict: python内置的高级数据类型.
        from collection import OrderedDict
        """

        return JsonResponse(serialzier.data,safe=False)

    def get(self,request):
        student = Student.objects.get(pk=1)
        print(student)
        serializer = StudentSerializer(instance=student)
        print(serializer.data)
        """打印效果:
        {'name': '小黑', 'age': 22, 'sex': True}
        """
        return JsonResponse(serializer.data)