from django.views import View
from django.http.response import HttpResponse,JsonResponse
from .serializers import StudentSerializer
from students.models import Student
class StudentView(View):
    def post(self,request):
        import json
        data = json.loads(request.body)
        # 反序列化
        # 1. 实例化序列化器对象
        serializer = StudentSerializer(data=data)
        # 2. 调用验证方法
        # raise_exception=True 表示当验证失败以后,不再执行后续代码,直接抛出错误
        ret = serializer.is_valid(raise_exception=True)
        print(ret) # ret为True表示验证通过,否则验证失败!
        # 验证通过,则会返回验证后的数据到validated_data属性方法
        print("成功", serializer.validated_data)
        """例如:
        成功 OrderedDict([('name', '小明'), ('age', 12), ('sex', True), ('class_num', '303'), ('description', '成功的提交数据很重要')])
        """
        # 验证失败,则有错误
        print("失败",serializer.errors)
        """例如:
        失败 {'description': [ErrorDetail(string='This field is required.', code='required')]}
        """
        # 执行数据库操作
        serializer.save() # 这里会自动调用序列化器内的create或者update方法

        return HttpResponse("OK")


    def put(self,request):
        """修改数据"""
        # 接收客户端提交的修改数据并获取要更新字段的模型对象
        import json
        data = json.loads(request.body)
        id = data.get("id")
        student = Student.objects.get(pk=id)
        # 创建序列化器对象
        # partial=True表示设置值验证客户端上传来的部分数据,没有上传的字段,即便有选项或者验证方法,也忽略不管.
        serializer = StudentSerializer(instance=student, data=data, partial=True)
        serializer.is_valid(raise_exception=True)
        # 执行数据库操作
        serializer.save() # 这里会自动调用序列化器内的create或者update方法
        """
        serializer.save()之所以会自动判断什么时候执行create和update,
        原因是save内部中根据实例化序列化器时是否传递模型对象参数进来而判断的.
        """
        return HttpResponse("更新完成")

    def get(self,request):
        student = Student.objects.get(pk=3)
        serializer = StudentSerializer(instance=student)
        return JsonResponse(serializer.data)

from .serializers import StudentModelSerializer
class Student2View(View):
    def get(self,request):
        student = Student.objects.get(pk=3)
        serializer = StudentModelSerializer(instance=student)
        return JsonResponse(serializer.data)

    def post(self,request):
        import json
        data = json.loads(request.body)
        # 反序列化
        # 1. 实例化序列化器对象
        serializer = StudentModelSerializer(data=data)
        # 2. 调用验证方法
        serializer.is_valid(raise_exception=True)
        serializer.save()  # 这里会自动调用序列化器内的create或者update方法
        return JsonResponse(serializer.data)