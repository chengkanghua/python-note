from rest_framework import serializers
from .models import Student
class StudentModelSerializer(serializers.ModelSerializer):
    """学生信息序列化器"""
    # 1. 字段声明

    # 2. 模型序列化器相关声明
    class Meta:
        model = Student
        fields = "__all__"
    # 3. 验证代码[反序列化]

    # 4. 操作数据代码[反序列化器]