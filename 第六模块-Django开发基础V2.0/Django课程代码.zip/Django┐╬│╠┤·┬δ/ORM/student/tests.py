from django.test import TestCase

# Create your tests here.




# l1 = [1,2,3]
# l2 = [4,5,6]



print("hello".upper())

l1 = ["alvin","rain"]

print(l1[0].upper())


