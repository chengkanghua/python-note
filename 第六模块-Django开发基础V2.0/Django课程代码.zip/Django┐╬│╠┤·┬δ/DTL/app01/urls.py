from django.contrib import admin
from django.urls import path, include

from app01.views import index, order

urlpatterns = [

    path('index/', index, name="ind"),
    path('order/', order, name="ord"),

]


