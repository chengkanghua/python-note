from django.apps import AppConfig


class CookieConfig(AppConfig):
    name = 'cookie'
